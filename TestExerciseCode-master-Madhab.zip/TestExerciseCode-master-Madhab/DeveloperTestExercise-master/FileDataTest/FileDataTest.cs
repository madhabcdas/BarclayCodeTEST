﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace FileDataTest
{
    [TestClass]
    public class FileDataTest
    {
        [TestMethod]
        public void TestMethod1()
        {
            
        }
    }
}
